module.exports = {
  content: [
    "./index.php",
    "./Resources/**/*.blade.php",
    "./Resources/**/*.js",
    "./Resources/**/*.ts",
    "./Resources/**/*.vue",
  ],
  prefix: 'go-',
  theme: {
    extend: {},
  },
  plugins: [],
}
