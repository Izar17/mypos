<?php

namespace Modules\NsGastro\Tests\Feature;

use Tests\Feature\RefreshReportForPassDaysTest;

class GastroRefreshReportForPastDaysTest extends RefreshReportForPassDaysTest
{
    // ...
}
