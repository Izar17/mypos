<?php

namespace Modules\NsGastro\Tests\Feature;

use Illuminate\Foundation\Testing\WithFaker;
use Tests\Feature\CreateProviderTest;

class GastroCreateProviders extends CreateProviderTest
{
    use WithFaker;

    // ...
}
