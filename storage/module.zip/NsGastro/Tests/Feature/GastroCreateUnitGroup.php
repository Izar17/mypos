<?php

namespace Modules\NsGastro\Tests\Feature;

use Illuminate\Foundation\Testing\WithFaker;
use Tests\Feature\CreateUnitGroupTest;

class GastroCreateUnitGroup extends CreateUnitGroupTest
{
    use WithFaker;

    // ...
}
