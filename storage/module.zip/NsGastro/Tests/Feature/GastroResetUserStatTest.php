<?php

namespace Modules\NsGastro\Tests\Feature;

use Tests\Feature\ResetUserStatsTest;

class GastroResetUserStatTest extends ResetUserStatsTest
{
    // ...
}
