<?php

namespace Modules\NsGastro\Tests\Feature;

use Illuminate\Foundation\Testing\WithFaker;
use Tests\Feature\MakeProcurementTest;

class GastroCreateProcurements extends MakeProcurementTest
{
    use WithFaker;

    // ...
}
