<?php

namespace Modules\NsGastro;

use App\Services\Module;

class NsGastroModule extends Module
{
    public function __construct()
    {
        parent::__construct(__FILE__);
    }
}
